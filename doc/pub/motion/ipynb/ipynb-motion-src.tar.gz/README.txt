This IPython notebook motion.ipynb does not require any additional
programs.
