This IPython notebook energyconserv.ipynb does not require any additional
programs.
