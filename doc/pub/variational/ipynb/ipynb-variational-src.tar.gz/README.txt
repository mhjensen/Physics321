This IPython notebook variational.ipynb does not require any additional
programs.
