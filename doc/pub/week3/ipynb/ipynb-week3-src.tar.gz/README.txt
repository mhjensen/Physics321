This IPython notebook week3.ipynb does not require any additional
programs.
