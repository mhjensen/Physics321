This IPython notebook week11.ipynb does not require any additional
programs.
