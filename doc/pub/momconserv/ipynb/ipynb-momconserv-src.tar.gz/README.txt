This IPython notebook momconserv.ipynb does not require any additional
programs.
