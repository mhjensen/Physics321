This IPython notebook gravity.ipynb does not require any additional
programs.
