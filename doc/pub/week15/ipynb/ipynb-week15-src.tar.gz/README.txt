This IPython notebook week15.ipynb does not require any additional
programs.
