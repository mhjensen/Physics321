This IPython notebook twobody.ipynb does not require any additional
programs.
