This IPython notebook lagrange.ipynb does not require any additional
programs.
