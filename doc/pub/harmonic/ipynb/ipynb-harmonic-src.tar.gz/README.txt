This IPython notebook harmonic.ipynb does not require any additional
programs.
