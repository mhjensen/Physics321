This IPython notebook hw8.ipynb does not require any additional
programs.
