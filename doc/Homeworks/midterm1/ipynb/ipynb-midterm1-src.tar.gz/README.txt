This IPython notebook midterm1.ipynb does not require any additional
programs.
