This IPython notebook hw7.ipynb does not require any additional
programs.
