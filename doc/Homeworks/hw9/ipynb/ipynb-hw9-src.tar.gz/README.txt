This IPython notebook hw9.ipynb does not require any additional
programs.
