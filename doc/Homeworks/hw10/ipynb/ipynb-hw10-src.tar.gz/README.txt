This IPython notebook hw10.ipynb does not require any additional
programs.
