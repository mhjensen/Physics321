This IPython notebook hw6.ipynb does not require any additional
programs.
