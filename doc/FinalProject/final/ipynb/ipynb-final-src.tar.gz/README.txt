This IPython notebook final.ipynb does not require any additional
programs.
