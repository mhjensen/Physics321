This IPython notebook Secondmidterm2022.ipynb does not require any additional
programs.
