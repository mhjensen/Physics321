This IPython notebook first.ipynb does not require any additional
programs.
