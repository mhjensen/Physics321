This IPython notebook Firstmidterm2023.ipynb does not require any additional
programs.
