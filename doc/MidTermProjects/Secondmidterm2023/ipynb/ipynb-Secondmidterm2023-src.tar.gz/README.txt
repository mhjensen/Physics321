This IPython notebook Secondmidterm2023.ipynb does not require any additional
programs.
