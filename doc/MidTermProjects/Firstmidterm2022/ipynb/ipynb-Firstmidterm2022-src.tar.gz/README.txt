This IPython notebook Firstmidterm2022.ipynb does not require any additional
programs.
