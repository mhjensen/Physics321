This IPython notebook Firstmidterm2021.ipynb does not require any additional
programs.
